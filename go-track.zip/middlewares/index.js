import errorHandler from "./errorHandler.js";
import authorize from "./auth.js";

export default {
  errorHandler,
  authorize,
};
