export default [
  "ADMIN",
  "CANDIDATE",
];
