import * as path from "path";
export const __dirname = path.resolve(path.dirname(''));
export const UPLOAD_PATH = process.env.UPLOAD_PATH;